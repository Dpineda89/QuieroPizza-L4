﻿using System;

namespace ServiTec.Bl
{
    public class Class1
    {
    }
}
