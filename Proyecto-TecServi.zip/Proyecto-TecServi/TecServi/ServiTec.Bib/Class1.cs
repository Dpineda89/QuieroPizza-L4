﻿using System;

namespace ServiTec.Bib
{
    public class Class1
    {
    }
}
